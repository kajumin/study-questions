<?php

/**
 * 定义公共的配置信息
 * 1. 便于维护
 * 2. 公共使用
 */

define('SYSTEM_NAME', 'HELLO');
define('SYSTEM_VERSION', '1.0.0');
define('DB_HOST', '192.168.110.120');
