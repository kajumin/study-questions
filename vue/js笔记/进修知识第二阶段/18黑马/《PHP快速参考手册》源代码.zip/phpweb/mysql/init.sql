create database if not exists cdb_demo;
use cdb_demo;

create table user_main(
userid bigint auto_increment not null,
email varchar(50) not null unique,
password varchar(50) not null,
sex int default 0 check(sex>=0 and sex<=2),
phone varchar(50) default null,
acceptemail int default 0 check(acceptemail>=0 and acceptemail<=1),
islocked int default 1 check(islocked>=0 and islocked<1),
primary key (userid)
)engine=innodb;