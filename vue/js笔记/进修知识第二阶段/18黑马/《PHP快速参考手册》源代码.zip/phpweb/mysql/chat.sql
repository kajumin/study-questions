use cdb_demo;

create table chat(
rid serial,
email varchar(50) not null,
msg varchar(50) not null,
creationtime datetime,
creationip varchar(23)
);