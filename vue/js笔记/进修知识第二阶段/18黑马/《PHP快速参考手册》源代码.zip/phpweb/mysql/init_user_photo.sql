use cdb_demo;

alter table user_main
add photo varchar(50) default null;
