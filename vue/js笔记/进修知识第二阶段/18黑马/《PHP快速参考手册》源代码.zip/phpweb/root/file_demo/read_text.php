<?php

$filename = $_SERVER["DOCUMENT_ROOT"]."/file_demo/myfile.txt";
$fp = fopen($filename, "r");

echo fgets($fp);
echo fgets($fp);
echo fgets($fp);

fclose($fp);

?>