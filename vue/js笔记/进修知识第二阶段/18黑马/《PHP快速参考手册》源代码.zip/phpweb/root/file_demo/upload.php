<?php 
require_once $_SERVER["DOCUMENT_ROOT"]."/phpapp/app.php";

// 是否接收提交
if (!isset($_FILES["photo"]))
	invalid("没有收到上传文件");

// 上传状态
$photo = $_FILES["photo"];
if ($photo["error"] == 1)
    invalid("上传的文件太大了！:)");
elseif ($photo["error"] != 0)
	invalid("上传文件异常，请重试");
	
// 检查文件类型，支持三种图片
$arrtype = array("image/jpeg","image/png","image/gif");
if (!in_array($photo["type"], $arrtype))
	invalid("图片格式只支持JPEG、PNG和GIF");

// 保存文件名
$farr = explode(".", $photo["name"]);
$filename = CStr::getGuid().".".end($farr);
$path = $_SERVER["DOCUMENT_ROOT"]."/app/photo/$filename";

// 保存上传文件
if(@move_uploaded_file($photo["tmp_name"], $path)){
	// 文件名保存到数据库
	$user = new CUser();
	$data = array("photo"=>$filename);
	$cond = array("email"=>"tom@xyz.com");
	if( $user->save($data, $cond)>0)
		echo "文件已成功上传，<a href='/'>返回主页</a>";	
	else
		invalid("保存用户照片信息错误，请稍后重试");
}else{
	invalid("文件上传失败，请稍后重试");
}





// 统一的错误处理
function invalid($msg)
{
	$maxfiles = ini_get("max_file_uploads");
	$postmax = ini_get("post_max_size");
	$maxfilesize = ini_get("upload_max_filesize");
	echo <<<HTML
	<h3>文件上传失败！</h3>
	<p>$msg
	<h3>上传要求:</h3>
	<ul>
	<li>最大上传数量$maxfiles
	<li>最大上传尺寸$postmax
	<li>单个文件最大尺寸$maxfilesize
	<li>支持图片格式 JPEG、PNG和GIF
	</ul>
	<p><a href="upload.html">返回上传页面</a>
HTML;
	exit;
}
?>