<?php

$filename1 = $_SERVER["DOCUMENT_ROOT"]."/file_demo/myfile.txt";
$filename2 = $_SERVER["DOCUMENT_ROOT"]."/file_demo/myfile_copy.txt";
$fp1 = fopen($filename1, "r");
$fp2 = fopen($filename2, "w");

while(!feof($fp1))
{
	$data = fread($fp1, 4096);
	fwrite($fp2, $data);
}

fclose($fp1);
fclose($fp2);

?>