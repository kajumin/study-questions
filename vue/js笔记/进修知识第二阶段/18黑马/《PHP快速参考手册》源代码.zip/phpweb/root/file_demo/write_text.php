<?php

$filename = $_SERVER["DOCUMENT_ROOT"]."/file_demo/myfile.txt";
$fp = fopen($filename, "w+");

echo var_dump(fputs($fp, "abc\n"));
echo var_dump(fputs($fp, "def\n"));
echo var_dump(fputs($fp, "ghi\n"));

fclose($fp);

?>