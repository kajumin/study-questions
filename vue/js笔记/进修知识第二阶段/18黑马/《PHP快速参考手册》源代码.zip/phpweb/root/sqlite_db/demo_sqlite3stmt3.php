<?php
// 打开SQLite演示数据库
$dbpath = $_SERVER['DOCUMENT_ROOT'].'/sqlite_db/cdb_demo.db';
//
$db = new SQLite3($dbpath);
$sql = "select * from user_main where email=:email;";
//
$stmt = $db->prepare($sql);
$stmt->bindValue(":email", "tom@xyz.com");
//
$result = $stmt->execute();
while($record = $result->fetchArray(SQLITE3_ASSOC))
{
	foreach($record as $name=>$value)
	{
		echo $name,' = ',$value,'<br>';
	}
}
//
$stmt->close();
$db->close();
?>