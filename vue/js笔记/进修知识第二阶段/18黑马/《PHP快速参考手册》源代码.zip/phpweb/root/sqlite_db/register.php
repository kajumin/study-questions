<style type="text/css">
input:required {background-color:lightyellow;}
input:invalid {background-color:lightpink;}
</style>

<form id="register" name="register" method="post" action="registerResult.php">
<fieldset><legend>请输入您的注册信息</legend>

<p><label for="email">您的E-mail</label>
<input type="email" id="email" name="email" maxlength="50" required>

<p><label for="password">登录密码</label>
<input type="password" id="password" name="password" maxlength="15" required>

<p><label for="confirm">密码确认</label>
<input type="password" id="confirm" name="confirm" maxlength="15" 
	oninput="pwd_validate(this);" required>

	<p><label for="sex">您的称呼</label>
<input type="radio" id="sex" name="sex" value="1">先生
<input type="radio" name="sex" value="2">女士
<input type="radio" name="sex" value="0" checked>保密

<p><input id="acceptemail" name="acceptemail" type="checkbox" checked>
<label for="">接收我们的邮件</label>
</fieldset>

<input type="submit" value="提交">
<input type="reset" value="默认值">
</form>

<script type="text/javascript">
// 页面标题
document.title = "用户注册";
// 密码验证
function pwd_validate(e)
{
	if(e.value.length<6)
		e.setCustomValidity("登录密码最少需要6个字符");
	else if(document.getElementById("password").value != 
		document.getElementById("confirm").value)
		e.setCustomValidity("密码两次输入不一致");
	else
		e.setCustomValidity("");
}

// 载入表单cookie数据
window.onload = function loadCookie()
{
	
}
</script>