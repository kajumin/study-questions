<?php
// 打开SQLite演示数据库
$dbpath = $_SERVER['DOCUMENT_ROOT'].'/sqlite_db/cdb_demo.db';
//
$db = new SQLite3($dbpath);
$sql = <<<SQL
insert into user_main(email,password,sex,phone,acceptemail,islocked)
values(?,?,?,?,?,?);
SQL;
//
$stmt = $db->prepare($sql);
$stmt->bindValue(1, "smith@xyz.com");
$stmt->bindValue(2, sha1('123456'));
$stmt->bindValue(3, 1);
$stmt->bindValue(4, "123456");
$stmt->bindValue(5, 1);
$stmt->bindValue(6, 0);
//
$stmt->execute();
echo $db->lastInsertRowId();
$stmt->close();
$db->close();
?>