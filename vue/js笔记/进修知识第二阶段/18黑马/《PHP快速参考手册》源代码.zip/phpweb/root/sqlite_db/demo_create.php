<?php
// 创建SQLite演示数据库
$dbpath = $_SERVER['DOCUMENT_ROOT'].'/sqlite_db/cdb_demo.db';
//
$db = new SQLite3($dbpath);
// 创建数据表SQL
$sql = <<<SQL
create table user_main (
userid integer primary key,
sex integer,
email text unique,
password text,
phone text,
acceptemail integer,
islocked integer
);
SQL;
//
var_dump($db->exec($sql));
$db->close();
?>
