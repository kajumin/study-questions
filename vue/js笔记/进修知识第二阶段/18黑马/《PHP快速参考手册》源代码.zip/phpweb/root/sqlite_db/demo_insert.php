<?php
// 创建SQLite演示数据库
$dbpath = $_SERVER['DOCUMENT_ROOT'].'/sqlite_db/cdb_demo.db';
//
$db = new SQLite3($dbpath);
// 添加新数据
$email = 'tom@xyz.com';
$password = sha1('123456');
$sex = 1;
$phone = '123456';
$acceptemail = 1;
$islocked = 0;
//
$sql = <<<SQL
insert into user_main(email,password,sex,phone,acceptemail,islocked)
values('$email','$password',$sex,'$phone',$acceptemail,$islocked);
SQL;
//
var_dump($db->exec($sql));
$db->close();
?>