<?php
extract($_REQUEST);
if(!isset($email) || !isset($password))
	invalid("请输入正确的登录信息");

// 打开SQLite演示数据库
$dbpath = $_SERVER['DOCUMENT_ROOT'].'/sqlite_db/cdb_demo.db';
$db = new SQLite3($dbpath);
$sql = <<<SQL
select email from user_main 
where email=:email and password=:password and islocked=0;
SQL;
$stmt = $db->prepare($sql);
$stmt->bindParam(":email", $email);
$stmt->bindValue(":password", sha1($password));
$result = $stmt->execute();
$record = $result->fetchArray();
if(isset($record[0]) && strcasecmp($record[0],$email)==0)
{
    // 登录成功，返回主页
    session_start();
    $_SESSION['email']=$email;
    header("Location: /");
}else{
	invalid("登录失败，请检查您的登录信息");
}


// 登录失败，返回登录页
function invalid($msg)
{
	// 显示提示信息，并返回login.php
	echo "<script type='text/javascript'>";
	echo "alert('",$msg,"');";
	echo "window.open('login.php','_self');";
	echo "</script>";
	exit;
}
?>