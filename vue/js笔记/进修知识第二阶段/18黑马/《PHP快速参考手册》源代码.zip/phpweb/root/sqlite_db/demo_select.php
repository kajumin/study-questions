<?php
// 创建SQLite演示数据库
$dbpath = $_SERVER['DOCUMENT_ROOT'].'/sqlite_db/cdb_demo.db';
//
$db = new SQLite3($dbpath);
$db->close();
$db->open($dbpath);
// 搜索数据
$sql = "select * from user_main where email='tom@xyz.com' limit 1;";
//
$result = $db->query($sql);
$record = $result->fetchArray();
foreach($record as $name=>$value)
{
	echo $name,' = ',$value,'<br>';
}
//
$result->finalize();
$db->close();
?>