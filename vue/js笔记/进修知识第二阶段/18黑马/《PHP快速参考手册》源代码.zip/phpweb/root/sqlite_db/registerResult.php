<?php
// 分解用户提交数据
extract($_REQUEST);
if(!isset($email))
{
	header("Location: register.php");
	exit;
}

// 检查E-mail地址
$pattern = '/^[a-zA-Z0-9]+-*[a-zA-Z0-9]*@[a-zA-Z0-9]+-*.[a-zA-Z]+.?[a-zA-Z]+$/';
if (preg_match($pattern, $email)!=1)
	//exit('E-mail地址格式错误');
	invalid('E-mail地址格式错误');
// 检查密码
if (strlen($password)<6 || strcmp($password,$confirm)!=0)
	//exit('密码至少6个字符，并且两次输入要一致');
	invalid('密码至少6个字符，并且两次输入要一致');
// 检查性别
$sex = intval($sex);
if ($sex<0 || $sex>2)
	//exit('性别值应该是0到2');
	invalid('性别值应该是0到2');
// 是否接收邮件
if (isset($acceptemail))
	$acceptemail = 1;
else
	$acceptemail = 0;
//
//
// 保存到cdb_demo.db数据库(SQLite3)
// 打开SQLite演示数据库
$dbpath = $_SERVER['DOCUMENT_ROOT'].'/sqlite_db/cdb_demo.db';
$db = new SQLite3($dbpath);
// 检查E-mail地址是否已使用
$sql = "select userid from user_main where email=:email;";
$stmt = $db->prepare($sql);
$stmt->bindParam(":email", $email);
$result = $stmt->execute();
$record = $result->fetchArray(SQLITE3_ASSOC);
if(isset($record["userid"]) && is_int($record["userid"]) && $record["userid"]>0)
	invalid('E-mail地址已使用');


// 保存到数据库
$sql = <<<SQL
insert into user_main(email,password,sex,acceptemail,phone,islocked)
values (:email,:password,:sex,:acceptemail,null,0);
SQL;
$stmt = $db->prepare($sql);
$stmt->bindParam(":email", $email);
$stmt->bindValue(":password", sha1($password));
$stmt->bindParam(":sex", $sex);
$stmt->bindParam(":acceptemail", $acceptemail);
$stmt->execute();
$newid = $db->lastInsertRowId();
//
$stmt->close();
$db->close();
//
if ($newid > 0)
	header("Location: login.php");
else
	invalid("对不起！系统繁忙，请稍后再试！");
//

// 验证失败，返回注册页
function invalid($msg)
{
	// 显示提示信息，并返回register.php
	echo "<script type='text/javascript'>";
	echo "alert('",$msg,"');";
	echo "window.history.back();";
	echo "</script>";
	exit;
}
?>