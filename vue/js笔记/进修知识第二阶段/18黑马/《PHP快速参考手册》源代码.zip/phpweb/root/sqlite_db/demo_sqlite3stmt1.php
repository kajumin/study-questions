<?php
// 创建SQLite演示数据库
$dbpath = $_SERVER['DOCUMENT_ROOT'].'/sqlite_db/cdb_demo.db';
//
$db = new SQLite3($dbpath);
$sql = <<<SQL
insert into user_main(email,password,sex,phone,acceptemail,islocked)
values(?,?,?,?,?,?);
SQL;
//
$email = "john@xyz.com";
$password = sha1('123456');
$sex = 1;
$phone = "123456";
$acceptemail = 1;
$islocked = 0;
//
$stmt = $db->prepare($sql);
$stmt->bindParam(1, $email);
$stmt->bindParam(2, $password);
$stmt->bindParam(3, $sex);
$stmt->bindParam(4, $phone);
$stmt->bindParam(5, $acceptemail);
$stmt->bindParam(6, $islocked);
//
$stmt->execute();
echo $db->lastInsertRowId();
$stmt->close();
$db->close();
?>