<?php
// 创建SQLite演示数据库
$dbpath = $_SERVER['DOCUMENT_ROOT'].'/sqlite_db/cdb_demo.db';
//
$db = new SQLite3($dbpath);
// 搜索数据
$sql = "update user_main set sex=0 where email='tom@xyz.com';";
//
var_dump($db->exec($sql));
$db->close();
?>