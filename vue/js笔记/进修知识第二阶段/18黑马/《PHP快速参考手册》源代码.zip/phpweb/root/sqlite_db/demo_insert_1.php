<?php
// 打开SQLite演示数据库
$dbpath = $_SERVER['DOCUMENT_ROOT'].'/sqlite_db/cdb_demo.db';
//
$db = new SQLite3($dbpath);
// 添加新数据
$email = 'jerry@xyz.com';
$password = sha1('456789');
$sex = 1;
$phone = '456789';
$islocked = 0;
//
$sql = <<<SQL
insert into user_main(email,password,sex,phone,islocked)
values('$email','$password',$sex,'$phone',$islocked);
SQL;
//
$db->close();
?>