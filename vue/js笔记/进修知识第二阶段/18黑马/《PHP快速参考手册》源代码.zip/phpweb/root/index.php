<?php
require_once $_SERVER["DOCUMENT_ROOT"]."/app/init.php";
class CTest
{
    // 析构函数
    public function __destruct()
    {
        echo '对象任务已完成';
    }
}

$obj = new CTest();
unset($obj);

?>


