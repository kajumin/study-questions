<?php

require_once $_SERVER["DOCUMENT_ROOT"]."/lib/db.php";
require_once $_SERVER["DOCUMENT_ROOT"]."/lib/CMySql.php";

class CMySqlEngine implements IDbEngine
{
	private $host;
	private $user;
	private $pwd;
	private $dbname;
	private $port;
	private $socket;
	
	// 构造函数
	public function __construct($host,$user,$pwd,$dbname,$port=3306,$socket="")
	{
		$this->host = $host;
		$this->user = $user;
		$this->pwd = $pwd;
		$this->dbname = $dbname;
		$this->port = $port;
		$this->socket = $socket;
	}
	//
	public function getEngineType()
	{
		return DbEngineType::MYSQL;
	}
	//
	public function getDb()
	{
		return new mysqli($this->host,
			$this->user,
			$this->pwd,
			$this->dbname,
			$this->port,
			$this->socket);
	}
	//
	public function connect()
	{
		try
		{
			$db = $this->getDb();
			$rv = $db->ping();
			$db->close();
			return $rv;
		}
		catch(Exception $ex)
		{
			return false;
		}
	}
	// 返回一个查询，没有返回false
	public function getValue($table, $returnfields, array $cond)
	{
		$db = $this->getDb();
		$sql = CMySql::getSelectSql($table, $returnfields, 1, $cond);
		$stmt = $db->prepare($sql);
		CMySql::addQueryData($stmt, $cond);
		$rv = $stmt->execute();
		if ($rv)
		{
			$result = $stmt->get_result();
			$record = $result->fetch_row();
			if (is_array($record) && count($record)>0)
				$rv = $record[0];
			$result->free();
		}
		$stmt->close();
		$db->close();
		return $rv;
	}
	
	// 返回array或false，只按返回字段名返回数据
    public function getRecord($table, $returnfields, array $cond)
	{
		$db = $this->getDb();
		$sql = CMySql::getSelectSql($table, $returnfields, 1, $cond);
		$stmt = $db->prepare($sql);
		CMySql::addQueryData($stmt, $cond);
		$rv = $stmt->execute();
		if ($rv)
		{
			$result = $stmt->get_result();
			$record = $result->fetch_assoc();
			//
			if ($record == null) 
				$rv = false;
			else
				$rv=$record;
			//
			$result->free();
		}
		$stmt->close();
		$db->close();
		return $rv;
	}
	
	// 返回二维数组或或false
    public function getRecordset($table, $returnfields, $returncount, array $cond)
	{
		$db = $this->getDb();
		$sql = CMySql::getSelectSql($table, $returnfields, $returncount, $cond);
		$stmt = $db->prepare($sql);
		CMySql::addQueryData($stmt, $cond);
		$rv = $stmt->execute();
		if ($rv)
		{
			$result = $stmt->get_result();
			if ($result->num_rows > 0)
			{
				$rv = array();
				while($record = $result->fetch_assoc())
				{
					array_push($rv, $record);
				}
			}
			$result->free();
		}
		$stmt->close();
		$db->close();
		return $rv;
	}
	//

}

?>