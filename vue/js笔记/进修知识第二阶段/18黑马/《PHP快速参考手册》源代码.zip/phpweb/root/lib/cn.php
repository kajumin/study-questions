<?php
/*
* 包含与中国相关的日期、时间等与区域相关的操作代码
*/

// 设置时区
function cnSetTimezone()
{
	date_default_timezone_set("Asia/Shanghai");
}

// 给出中国日期长格式字符串
function cnGetLongDateString($ts=NULL)
{
	cnSetTimezone();
	if (!is_int($ts)) $ts = time();
	return date("Y年m月d日",$ts);
}

// 给出中国日期短格式字符串
function cnGetShortDateString($ts=NULL)
{
	cnSetTimezone();
	if (!is_int($ts)) $ts = time();
	return date("Y-m-d",$ts);
}

// 判断是否为闰年
function isLeapYear($ts=NULL)
{
	cnSetTimezone();
	if (!is_int($ts)) $ts = time();
	return (bool)date("L",$ts);
}

// 给出标准的日期时间串
function getDateTimeString($ts=NULL)
{
	cnSetTimezone();
	if (!is_int($ts)) $ts = time();
	return date("Y-m-d H:i:s", $ts);
}

// 给出中文星期名称
function cnGetWeekName($ts=NULL)
{
	cnSetTimezone();
	if (!is_int($ts)) $ts = time();
	$week = intval(date("w", $ts));
	return array("星期日","星期一","星期二",
		"星期三","星期四","星期五","星期六")[$week];
}
?>