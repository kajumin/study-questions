<?php

// 数据引擎类型
class DbEngineType
{
	const UNKNOW = 0;
	const SQLSERVER = 1;
    const MYSQL = 3;
    const ORACLE = 4;
	const SQLITE = 5;
}

// 数据引擎
interface IDbEngine
{
    function getEngineType();
    function connect();
	function getDb();
    function getValue($table, $returnfields, array $cond); 
    function getRecord($table, $returnfields, array $cond);
    function getRecordset($table, $returnfields, $returncount, array $cond);
}

// 数据表记录操作
interface IDbRecord
{
	function setDbEngine(IDbEngine $dbe);
	function getDbEngine();
	function getTableName();
	function getIdName();
	function save(array $data, array $cond);
	function load($returnfields, array $cond);
	function delete(array $cond);
	function find(array $cond, $notequalid);
}

?>