<?php

// 判断字符串是否为E-mail地址
function isEmail($str)
{
	$arr = explode('@',$str);
	if (strlen($str)<6 || count($arr)!=2) return false;
	$arr = explode('.',$arr[1]);
	$count = count($arr);
	if ($count<2 || $count>3) return false;
	return true;
}



?>