<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/lib/db.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/lib/CSqlite.php';

// SQLite数据库引擎
class CSqliteEngine implements IDbEngine
{
	private $dbfile;
	// 根据数据库连接串或数据文件初始化数据库引擎类
	public function __construct($dbfile)
	{
		$this->dbfile = $dbfile;
	}
	// 数据引擎类型
	public function getEngineType()
	{
		return DbEngineType::SQLITE;
	}
	
	// 连接测试
    public function connect()
	{
		try
		{
			$db = $this->getDb();
			$db->close();
			return true;
		}catch (Exception $ex) {
			return false;
		}
	}
	
	// 返回SQLite3对象
	public function getDb()
	{
		return new SQLite3($this->dbfile);
	}
	
	// 返回一个值或false
    public function getValue($table, $returnfields, array $cond)
	{
		$db = $this->getDb();
		$sql = CSqlite::getSelectSql($table,$returnfields,1,$cond);
		$stmt = $db->prepare($sql);
		CSqlite::addQueryData($stmt, $cond);
		$result = $stmt->execute();
		$record = $result->fetchArray(SQLITE3_NUM);
		$rv = false;
		if (isset($record[0])) $rv = $record[0];
		$result->finalize();
		$stmt->close();
		$db->close();
		return $rv;
	}
	
	// 返回array或false，只按返回字段名返回数据
    public function getRecord($table, $returnfields, array $cond)
	{
		$db = $this->getDb();
		$sql = CSqlite::getSelectSql($table,$returnfields,1,$cond);
		$stmt = $db->prepare($sql);
		CSqlite::addQueryData($stmt, $cond);
		$result = $stmt->execute();
		$record = $result->fetchArray(SQLITE3_ASSOC);
		$rv = false;
		if (is_array($record) && count($record)>0) $rv = $record;
		$result->finalize();
		$stmt->close();
		$db->close();
		return $rv;
	}
	
	// 返回二维数组或或false
    public function getRecordset($table, $returnfields, $returncount, array $cond)
	{
		$db = $this->getDb();
		$sql = CSqlite::getSelectSql($table,$returnfields,$returncount,$cond);
		$stmt = $db->prepare($sql);
		CSqlite::addQueryData($stmt, $cond);
		$result = $stmt->execute();
		$rv = array();
		while($record = $result->fetchArray(SQLITE3_ASSOC))
		{
			array_push($rv, $record);
		}
		$result->finalize();
		$stmt->close();
		$db->close();
		if (count($rv)>0)
			return $rv;
		else
			return false;
	}
}
?>