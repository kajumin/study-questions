<?php

// MySQL辅助操作代码

class CMySql
{
	// 向mysqli_stmt对象中传递参数
	public static function addQueryData(mysqli_stmt &$stmt, array &$data)
	{
		if(!is_array($data) || count($data)<1) return;
		// 确定数据类型，只支持ids
		$dbtype = "";
		foreach($data as $key=>$value)
		{
			if (is_int($value))
				$dbtype = $dbtype."i";
			elseif (is_float($value))
				$dbtype = $dbtype."d";
			else
				$dbtype = $dbtype."s";
		}
		// 引用数组
		$refarr = array();
		array_push($refarr, $dbtype);
		foreach($data as $key=>$value)
		{
			$refarr[$key]=&$data[$key];
		}
		@call_user_func_array(array($stmt,"bind_param"), $refarr);
	}
	
	// 创建select语句
	public static function getSelectSql($table, $returnfields="*", 
		$returncount=-1, $cond=array(), $idname="", $notequalid = -1)
	{
		$sql = "select $returnfields from $table ";
		if(is_array($cond) && count($cond)>0)
		{
			$sql = "$sql where ";
			$counter = 0;
			foreach($cond as $name=>$value)
			{
				if($counter>0) $sql="$sql and ";
				$sql="$sql $name=?";
				$counter++;
			}
		}
		//
		if($notequalid>0)
		{
			if(!is_array($cond) || count($cond)<1)
				$sql = "$sql where $idname<>$notequalid";
			else
				$sql = "$sql and $idname<>$notequalid";
		}
		//
		if($returncount>0)
			$sql = "$sql limit $returncount";
		//
		return "$sql;";
	}
	
	// 创建insert语句
	public static function getInsertSql($table, $data)
	{
		if(!is_array($data) || count($data)<1) return "";
		$sql = "insert into $table(";
		$values = ") values(";
		$counter = 0;
		foreach($data as $name=>$value)
		{
			if ($counter>0)
			{
				$sql = "$sql,";
				$values = "$values,";
			}
			$sql = "$sql$name";
			$values = "$values ?";
			$counter++;
		}
		return "$sql$values);";
	}
	
	// 创建update语句
	public static function getUpdateSql($table, $data, $cond)
	{
		if(!is_array($data) || count($data)<1) return "";
		if(!is_array($cond) || count($cond)<1) return "";
		$sql = "update $table set ";
		$counter = 0;
		// 更新数据
		foreach($data as $name=>$value)
		{
			if($counter>0) $sql="$sql,";
			$sql = "$sql $name=?";
			$counter++;
		}
		// 更新条件
		$counter=0;
		$sql = "$sql where ";
		foreach($cond as $name=>$value)
		{
			if($counter>0) $sql = "$sql and ";
			$sql = "$sql $name=?";
			$counter++;
		}
		//
		return "$sql;";
	}
	
	// 创建delete语句
	public static function getDeleteSql($table, $cond)
	{
		if(!is_array($cond) || count($cond)<1) return "";
		$sql = "delete from $table where ";
		$counter=0;
		foreach($cond as $name=>$value)
		{
			if($counter>0) $sql = "$sql and ";
			$sql = "$sql $name=?";
			$counter++;
		}
		return "$sql;";
	}
	
	//
}

?>