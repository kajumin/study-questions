<?php

class CCheckCode
{
	// 创建验证码
	public static function create($key, $len = 5)
	{
		// 初始化
		$width = $len*20;
		$height = 40;
		$img = imagecreatetruecolor($width, $height);
		$white = imagecolorallocate($img,255,255,255);
		imagefilledrectangle($img,0,0,$width,$height,$white);
		$colors = array(
			imagecolorallocate($img,47,79,79),
			imagecolorallocate($img,25,25,112),
			imagecolorallocate($img,139,58,58),
			imagecolorallocate($img,0,0,139),
			imagecolorallocate($img,28,28,28),
			imagecolorallocate($img,139,0,0),
			imagecolorallocate($img,104,34,139),
			imagecolorallocate($img,139,37,0)
		);
		$maxindex = count($colors)-1 ;
		// 绘制背景
		for($i=0; $i<5; $i++)
		{
			$x1 = rand(0,$width);
			$x2 = rand(0,$width);
			$y1 = rand(0,$height);
			$y2 = rand(0,$height);
			imageline($img,$x1,$y1,$x2,$y2,$colors[rand(0,$maxindex)]);
		}
		// 生成并显示代码
		$code = "";
		$fontfile = $_SERVER["DOCUMENT_ROOT"]."/fonts/simsun.ttc";
		for($i=0; $i<$len; $i++)
		{
			$ch = self::getChar();
			$x = $i*18+5;
			$angle = rand(-30, 30);
			imagettftext($img, rand(18,28),$angle,rand($x-5,$x+5),rand(25,40),
			    $colors[rand(0,$maxindex)],$fontfile,$ch);
			$code = $code.$ch;
		}
		// 绘制前景
		for($i=0; $i<5; $i++)
		{
			$x1 = rand(0,$width);
			$x2 = rand(0,$width);
			$y1 = rand(0,$height);
			$y2 = rand(0,$height);
			imageline($img,$x1,$y1,$x2,$y2,$white);
		}
		// 保存验证码
		CCheckCode::save($key, $code);
		// exit;
		//
		header("Content-type:image/png");
		imagepng($img);
		imagedestroy($img);
	}
	
	//
	private static function ($key, $code)
	{
		session_start();
		$_SESSION[$key] = $code;
	}
	
	// 给出一个随机字符，大写字母或数字
	public static function getChar()
	{
		if(rand(0,1)==0)
			return strval(rand(0,9)); // 数字
		else
			return chr(rand(65,90));
	}
	
	// 检查输入
	public static function check($key, &$input)
	{
		@session_start();
		if (isset($_SESSION[$key]) && strcmp($_SESSION[$key],$input)==0)
			return true;
		else
			return false;
	}
}


?>