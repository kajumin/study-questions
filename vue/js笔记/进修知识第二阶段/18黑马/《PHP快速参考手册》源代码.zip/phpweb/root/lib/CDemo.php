<?php

class CDemo
{
	public static $author = 'caohuayu.com';
	public function showInfo()
	{
		echo 'PHP Library';
	}
}

?>