<?php
/*
* 包含与中国相关的日期、时间等与区域相关的操作代码
*/
class CCn
{
	// 设置时区
	public static function setTimezone()
	{
		date_default_timezone_set("Asia/Shanghai");
	}

	// 给出中国日期长格式字符串
	public static function getLongDateString($ts=null)
	{
		self::setTimezone();
		if (!is_int($ts)) $ts = time();
		return date("Y年m月d日",$ts);
	}

	// 给出中国日期短格式字符串
	public static function getShortDateString($ts=null)
	{
		self::setTimezone();
		if (!is_int($ts)) $ts = time();
		return date("Y-m-d",$ts);
	}
	
	// 中文时间字符串
	public static function getLongTimeString($ts=null)
	{
		self::setTimezone();
		if (!is_int($ts)) $ts = time();
		return date("H时i分s秒", $ts);
	}
	
	// 标准时间字符串
	public static function getShortTimeString($ts=null)
	{
		self::setTimezone();
		if (!is_int($ts)) $ts = time();
		return date("H:i:s", $ts);
	}

	// 判断是否为闰年
	public static function isLeapYear($ts=null)
	{
		self::setTimezone();
		if (!is_int($ts)) $ts = time();
		return (bool)date("L",$ts);
	}

	// 给出标准的日期时间串"yyyy-mm-dd hh:mm:ss"
	public static function getDateTimeString($ts=null)
	{
		self::setTimezone();
		if (!is_int($ts)) $ts = time();
		return date("Y-m-d H:i:s", $ts);
	}

	// 给出中文星期名称
	public static function getWeekName($ts=null)
	{
		self::setTimezone();
		if (!is_int($ts)) $ts = time();
		$week = intval(date("w", $ts));
		return array("星期日","星期一","星期二",
			"星期三","星期四","星期五","星期六")[$week];
	}
}
?>