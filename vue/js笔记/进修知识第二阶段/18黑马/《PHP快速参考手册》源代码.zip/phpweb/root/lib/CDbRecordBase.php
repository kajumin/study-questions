<?php

require_once $_SERVER["DOCUMENT_ROOT"]."/lib/db.php";

abstract class CDbRecordBase implements IDbRecord
{
	private $dbengine;
	private $table;
	private $idname;
	
	// 构造函数
	public function __construct(IDbEngine $dbe, $tbl, $idname)
	{
		$this->dbengine = $dbe;
		$this->table = $tbl;
		$this->idname = $idname;
	}
	
	//
	public function setDbEngine(IDbEngine $dbe)
	{
		$this->dbengine = $dbe;
	}
	public function getDbEngine()
	{
		return $this->dbengine;
	}
	
	//
	public function getTableName()
	{
		return $this->table;
	}
	
	//
	public function getIdName()
	{
		return $this->idname;
	}
	
	// 载入一条记录
	public function load($returnfields, array $cond)
	{
		return $this->dbengine->getRecord($this->table,$returnfields,$cond);
	}
	//
	
	//
	// 保存
	public function save(array $data, array $cond)
	{
		if (!is_array($data) || count($data)<1) return 0;
		// data是否包含ID字段数据
		$idname = $this->getIdName();
		if (array_key_exists($idname, $data))
		{
			$cond = array($idname=>$data[$idname]);
			unset($data[$idname]);
			return $this->update($data, $cond);
		}elseif (!is_array($cond) || count($cond)<1){
			return $this->insert($data);
		}else{
			return $this->update($data, $cond);
		}
	}
	//
	protected abstract function insert(array $data);
	protected abstract function update(array $data, array $cond);
	//
	public abstract function delete(array $cond);
	// 判断是否有满足条件的记录，并返回其中一个ID(大于0)
	// 没有找到返回0
	public abstract function find(array $cond, $notequalid);
	//
}
?>