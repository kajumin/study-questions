<?php

class CStr
{
	// 返回32位的GUID字符串
	public static function getGuid()
	{
		return sprintf('%04x%04x%04x%04x%04x%04x%04x%04x', 
			mt_rand(0, 65535), mt_rand(0, 65535), 
			mt_rand(0, 65535), mt_rand(16384, 20479), 
			mt_rand(32768, 49151), mt_rand(0, 65535), 
			mt_rand(0, 65535), mt_rand(0, 65535));
	}
	
	// 判断字符串是否为E-mail地址
	function isEmail($str)
	{
		$arr = explode('@',$str);
		if (count($arr)!=2 || strlen($str)<6) return false;
		$arr = explode('.',$arr[1]);
		$count = count($arr);
		if ($count<2 || $count>3) return false;
		return true;
	}
}


?>