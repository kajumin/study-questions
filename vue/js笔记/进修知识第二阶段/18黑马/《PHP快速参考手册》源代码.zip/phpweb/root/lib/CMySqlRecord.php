<?php

require_once $_SERVER["DOCUMENT_ROOT"]."/lib/CDbRecordBase.php";

class CMySqlRecord extends CDbRecordBase
{
	// 查找记录，有结果返回其中一个ID值，否则返回0
	public function find(array $cond, $notequalid)
	{
		$db = $this->getDbEngine()->getDb();
		$sql = CMySql::getSelectSql($this->getTableName(),$this->getIdName(),
			1,$cond,$this->getIdName(), $notequalid);
		$stmt = $db->prepare($sql);
		CMySql::addQueryData($stmt, $cond);
		$rv = 0;		
		if($stmt->execute())
		{
			$result = $stmt->get_result();
			$record = $result->fetch_row();
			if(isset($record[0]) && is_int($record[0]) && $record[0]>0) 
				$rv = $record[0];
			$result->free();
		}
		$stmt->close();
		$db->close();
		return $rv;
	}
	// 删除记录，成功返回1，失败返回0
	public function delete(array $cond)
	{
		$sql = CMySql::getDeleteSql($this->getTableName(), $cond);
		if($sql == "" ) return 0;
		$db = $this->getDbEngine()->getDb();
		$stmt = $db->prepare($sql);
		CMySql::addQueryData($stmt, $cond);
		$rv = $stmt->execute();
		$stmt->close();
		$db->close();
		if ($rv) 
			return 1;
		else
			return 0;
	}
	
	// 保存数据
	// 添加数据
	protected function insert(array $data)
	{
		$sql = CMySql::getInsertSql($this->getTableName(), $data);
		if ($sql == "") return 0;
		$db = $this->getDbEngine()->getDb();
		$stmt = $db->prepare($sql);
		CMySql::addQueryData($stmt, $data);
		$rv = 0;
		//
		if ($stmt->execute())
		{
			$rv = $stmt->insert_id;
		}
		$stmt->close();
		$db->close();
		return $rv;
	}
	
	// 更新数据
	protected function update(array $data, array $cond)
	{
		$sql = CMySql::getUpdateSql($this->getTableName(), $data, $cond);
		if ($sql == "") return 0;
		$db = $this->getDbEngine()->getDb();
		$stmt = $db->prepare($sql);
		// 将条件值追加到$data，一起传递
		foreach($cond as $key=>$value)
		{
			$data[$key]=$value;
		}
		//
		CMySql::addQueryData($stmt, $data);
		$rv = 0;
		if ($stmt->execute())
			$rv = 1;
		$stmt->close();
		$db->close();
		return $rv;
	}
	
	//
}

?>