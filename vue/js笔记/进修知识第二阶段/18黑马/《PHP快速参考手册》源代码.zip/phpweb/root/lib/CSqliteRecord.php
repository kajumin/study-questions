<?php

require_once $_SERVER["DOCUMENT_ROOT"]."/lib/CDbRecordBase.php";
require_once $_SERVER["DOCUMENT_ROOT"]."/lib/CSqlite.php";

class CSqliteRecord extends CDbRecordBase
{
	// 查找记录，有结果返回其中一个ID值，否则返回0
	public function find(array $cond, $notequalid)
	{
		$db = $this->getDbEngine()->getDb();
		$sql = CSqlite::getSelectSql($this->getTableName(),$this->getIdName(),
			1,$cond,$this->getIdName(), $notequalid);
		$stmt = $db->prepare($sql);
		CSqlite::addQueryData($stmt, $cond);
		$result = $stmt->execute();
		$record = $result->fetchArray(SQLITE3_NUM);
		$rv = 0;
		if(isset($record[0]) && is_int($record[0]) && $record[0]>0) 
			$rv = $record[0];
		$result->finalize();
		$stmt->close();
		$db->close();
		return $rv;
	}
	
	// 删除指定的数据，成功返回1，失败返回0
	public function delete(array $cond)
	{
		$sql = CSqlite::getDeleteSql($this->getTableName(), $cond);
		if ($sql == "") return 0;
		$db = $this->getDbEngine()->getDb();
		$stmt = $db->prepare($sql);
		CSqlite::addQueryData($stmt, $cond);
		$stmt->execute();
		$stmt->close();
		$db->close();
		return 1;
	}
	

	// 保存
	// 添加新记录
	protected function insert(array $data)
	{
		try
		{
			$sql = CSqlite::getInsertSql($this->getTableName(), $data);
			$db = $this->getDbEngine()->getDb();
			$stmt = $db->prepare($sql);
			CSqlite::addQueryData($stmt, $data);
			$stmt->execute();
			$rv = $db->lastInsertRowId();
			$stmt->close();
			$db->close();
			return $rv;
		}catch (Exception $ex){
			return 0;
		}	
	}
	
	// 更新数据
	protected function update(array $data, array $cond)
	{
		try
		{
			$sql = CSqlite::getUpdateSql($this->getTableName(), $data, $cond);
			$db = $this->getDbEngine()->getDb();
			$stmt = $db->prepare($sql);
			// 合并数据和条件，一起传递参数
			foreach($cond as $key=>$value)
			{
				array_push($data, $value);
			}
			CSqlite::addQueryData($stmt, $data);
			$stmt->execute();
			$stmt->close();
			$db->close();
			return 1;
		}catch(Exception $ex){
			return 0;
		}
	}
	
	//
}

?>