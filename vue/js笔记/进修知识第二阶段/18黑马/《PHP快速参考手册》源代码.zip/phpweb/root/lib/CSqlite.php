<?php

// SQLite3 通用代码封装
class CSqlite
{
	// 在SQLite3Stmt对象中添加参数
	public static function addQueryData(SQLite3Stmt &$stmt, array $data)
	{
		if (!is_array($data) || count($data)<1) return;
		$counter = 1;
		foreach($data as $name=>$value)
		{
			$stmt->bindValue($counter, $value);
			$counter++;
		}
	}
	
	// 创建select语句
	public static function getSelectSql($table, $returnfields="*", 
		$returncount=-1, array  $cond=array(), $idname = "", $notequalid = -1)
	{
		$sql = "select $returnfields from $table";

		if (is_array($cond) && count($cond)>0)
		{
			// 添加查询条件
			$counter = 0;
			$sql = "$sql where ";
			foreach($cond as $name=>$value)
			{
				if ($counter>0) $sql="$sql and ";
				$sql = "$sql $name=?";
				$counter++;
			}
		}
		// 不等于ID值
		if($notequalid>0)
		{
			if(!is_array($cond) || count($cond)<1)
				$sql = "$sql where $idname<>$notequalid";
			else
				$sql = "$sql and $idname<>$notequalid";
		}
		// 读取数量
		if ($returncount>0)
			$sql = "$sql limit $returncount ";
		//
		return "$sql;";
	}
	
	// 创建insert语句
	public static function getInsertSql($table, array $data)
	{
		if (!is_array($data) || count($data)<1) return "";
		$sql = "insert into $table(";
		$values = ") values(";
		$counter = 0;
		foreach($data as $name=>$value)
		{
			if ($counter>0)
			{
				$sql = "$sql,";
				$values = "$values,";
			}
			$sql = $sql.$name;
			$values = $values."?";
			$counter++;
		}
		//
		return "$sql$values);";
	}
	
	// 创建update语句，必须有条件更新
	public static function getUpdateSql($table, array $data, array $cond)
	{
		if (!is_array($data) || count($data)<1) return "";
		if (!is_array($cond) || count($cond)<1) return "";
		$sql = "update $table set ";
		// 更新数据
		$counter = 0;
		foreach($data as $name=>$value)
		{
			if($counter>0) $sql="$sql,";
			$sql = "$sql $name=?";
			$counter++;
		}
		// 更新条件
		$sql = $sql." where ";
		$counter = 0;
		foreach($cond as $name=>$value)
		{
			if($counter>0) $sql = "$sql and ";
			$sql = "$sql $name=?";
			$counter++;
		}
		//
		return "$sql;";
	}
	
	// 创建delete语句，必须有条件删除
	public static function getDeleteSql($table, array $cond)
	{
		if (!is_array($cond) || count($cond)<1) return "";
		$sql = "delete from $table where ";
		$counter = 0;
		foreach($cond as $name=>$value)
		{
			if ($counter>0) $sql=$sql." and ";
			$sql = $sql."$name=?";
			$counter++;
		}
		return "$sql;";
	}
	
	//
}

?>