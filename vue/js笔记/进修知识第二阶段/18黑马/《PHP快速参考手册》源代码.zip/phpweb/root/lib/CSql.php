<?php


class CSql
{
	// 提取参数数据
	public static function getParams(array &$cond)
	{
		$params = null;
		if (count($cond)>0)
		{
			$params = array();
			foreach($cond as $value)
				array_push($params, $value);	
		}
		return $params;
	}
	
	// 创建select语句
	public static function getSelectSql($table, $returnfields="*", 
		$returncount=-1, &$cond=array(), $idname="", $notequalid = -1)
	{
		$sql = "select ";
		//
		if($returncount>0)
			$sql = "$sql top $returncount";
		//
		$sql = "$sql $returnfields from $table ";
		//
		if(is_array($cond) && count($cond)>0)
		{
			$sql = "$sql where ";
			$counter = 0;
			foreach($cond as $name=>$value)
			{
				if($counter>0) $sql="$sql and ";
				$sql="$sql $name=?";
				$counter++;
			}
		}
		// 不等于ID值
		if ($notequalid > 0)
		{
			if (is_array($cond) && count($cond)>0)
				$sql = "$sql and ";
			else
				$sql = "$sql where ";
			$sql = "$sql $idname<>$notequalid";
		}
		//
		return "$sql;";
	}
	
	// 给出delete语句，不允许无条件删除
	public static function getDeleteSql($table, array &$cond)
	{
		if (!is_array($cond) || count($cond)<1) return "";
		$sql = "delete from $table where ";
		$counter = 0;
		foreach($cond as $name=>$value)
		{
			if ($counter>0) $sql = "$sql and ";
			$sql = "$sql $name=? ";
			$counter++;
		}
		return "$sql ;";
	}
	
	// 给出insert语句
	public static function getInsertSql($table, array &$data, $idname)
	{
		if (!is_array($data) || count($data)<1) return "";
		$sql = "insert into $table(";
		$values = ") output inserted.".$idname." values(";
		$counter = 0;
		foreach($data as $name=>$value)
		{
			if ($counter>0)
			{
				$sql = "$sql ,";
				$values = "$values ,";
			}
			$sql = "$sql $name ";
			$values = "$values ? ";
			$counter++;
		}
		return "$sql $values );";
	}
	
	// 给出update语句，不允许条件更新
	public static function getUpdateSql($table, array &$data, array &$cond)
	{
		if (!is_array($data) || count($data)<1 || 
			!is_array($cond) || count($cond)<1) return "";
		$sql = "update $table set ";
		// 更新数据
		$counter = 0;
		foreach($data as $name=>$value)
		{
			if ($counter>0) $sql = "$sql ,";
			$sql = "$sql $name=? ";
			$counter++;
		}
		// 更新条件
		$sql = "$sql where ";
		$counter = 0;
		foreach($cond as $name=>$value)
		{
			if ($counter>0) $sql = "$sql and ";
			$sql = "$sql $name=? ";
			$counter++;
		}
		//
		return "$sql ;";
	}
	
	//
}
?>