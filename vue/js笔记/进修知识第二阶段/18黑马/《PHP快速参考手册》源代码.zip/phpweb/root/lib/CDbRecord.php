<?php


require_once $_SERVER["DOCUMENT_ROOT"]."/lib/CSqliteEngine.php";
require_once $_SERVER["DOCUMENT_ROOT"]."/lib/CSqliteRecord.php";
require_once $_SERVER["DOCUMENT_ROOT"]."/lib/CMySqlEngine.php";
require_once $_SERVER["DOCUMENT_ROOT"]."/lib/CMySqlRecord.php";

class CDbRecord implements IDbRecord
{
	private $dbrecord = null;
	//
	public static function createObject(IDbEngine $dbe, $table, $idname)
	{
		switch($dbe->getEngineType())
		{
			case DbEngineType::SQLITE:
				return new CSqliteRecord($dbe, $table, $idname);
			case DbEngineType::MYSQL:
				return new CMySqlRecord($dbe, $table, $idname);
			default:
				return null;
		}
	}
	
	// 构建函数
	public function __construct(IDbEngine $dbe, $table, $idname)
	{
		// 根据数据库引擎类创建相应的IDbReocrd对象
		$this->dbrecord = self::createObject($dbe, $table, $idname);
	}
	
	//
	public function setDbEngine(IDbEngine $dbe)
	{
		$this->dbrecord = self::createObject($dbe, 
			$this->dbrecord->getTableName(), $this->dbrecord->getIdName());
	}
	
	//
	public function getDbEngine()
	{
		return $this->dbrecord->getDbEngine();
	}
	
	//
	public function getTableName()
	{
		return $this->dbrecord->getTableName();
	}
	
	//
	public function getIdName()
	{
		return $this->dbrecord->getIdName();
	}
	
	//
	public function save(array $data, array $cond)
	{
		return $this->dbrecord->save($data, $cond);
	}
	
	//
	public function load($returnfields, array $cond)
	{
		return $this->dbrecord->load($returnfields, $cond);
	}
	
	//
	public function delete(array $cond)
	{
		return $this->dbrecord->delete($cond);
	}
	
	//
	public function find(array $cond, $notequalid = -1)
	{
		return $this->dbrecord->find($cond, $notequalid);
	}
	//
}

?>