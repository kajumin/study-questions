<?php

// HTML5表单

class CForm
{
	
	// input元素
	public static function input($idname,$type="text",$value="",$ext="")
	{
		echo "<input id='$idname' name='$idname' type='$type' 
			value='$value' $ext>";
	}
	
	// 单行文本
	public static function textbox($idname, $value="", 
		$maxlength=50, $width=200)
	{
		echo "<input id='$idname' name='$idname' type='text' 
			value='",htmlspecialchars($value),"' 
			maxlength='$maxlength' style='width:$width","px;'>";
	}
	
	// 密码
	public static function password($idname, $maxlength=50, $width=200)
	{
		echo "<input id='$idname' name='$idname' type='password' 
			maxlength='$maxlength' style='width:$width","px;'>";
	}
	 
	// textarea元素
	public static function textarea($idname,$value="",$width=200,$height=30)
	{
		echo "<textarea id='$idname' name='$idname' value='",
			htmlspecialchars($value),"'	style='width:$width",
			"px;height:$height","px;'></textarea>";
	}
	
	// 下拉列表
	public static function dropdownlist($idname, array $items, $selectedkey="")
	{
		echo "<select id='$idname' name='$idname' size='1'>";
		foreach($items as $key=>$value)
		{
			if($key==$selectedkey)
				echo "<option value='$key' selected>$value</option>";
			else
				echo "<option value='$key'>$value</option>";
		}
		echo "</select>";
	}
	
	// 单选列表
	public static function radiobuttonlist($name, array $items, $checkedkey="")
	{
		foreach($items as $key=>$value)
		{
			echo "<input name='$name' type='radio' value='$key'";
			if($key==$checkedkey) echo " checked";
			echo ">",$value,"&nbsp";
		}
	}
	
	// 复选框
	public static function checkbox($idname,$text,$checked=false)
	{
		echo "<input id='$idname' name='$idname' type='checkbox'";
		if($checked) echo " checked";
		echo "><label for='$idname'>$text</label>";
	}
	//
}

?>