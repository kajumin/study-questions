<?php

require_once $_SERVER["DOCUMENT_ROOT"]."/lib/CDbRecordBase.php";
require_once $_SERVER["DOCUMENT_ROOT"]."/lib/CSql.php";

class CSqlRecord extends CDbRecordBase
{
	public function find(array $cond, $notequalid)
	{
		$sql = CSql::getSelectSql($this->getTableName(), $this->getIdName(),1,
			$cond, $this->getIdName(), $notequalid);
		$db = $this->getDbEngine()->getDb();
		if($db==false) return 0;
		$stmt = sqlsrv_query($db, $sql, CSql::getParams($cond));
		$rv = 0;
		if ($stmt)
		{
			$record = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_NUMERIC);
			if(isset($record[0]) && is_int($record[0]) && $record[0]>0)
				$rv=$record[0];
			sqlsrv_free_stmt($stmt);
		}
		sqlsrv_close($db);
		return $rv;
	}
	
	// 删除记录，成功返回1，失败返回0
	public function delete(array $cond)
	{
		$sql = CSql::getDeleteSql($this->getTableName(), $cond);
		if($sql == "" ) return 0;
		$db = $this->getDbEngine()->getDb();
		if ($db===false) return 0;
		$stmt = sqlsrv_query($db, $sql, CSql::getParams($cond));
		$rv = 0;
		if($stmt)
		{	
			$rv = 1;
			sqlsrv_free_stmt($stmt);
		}
		sqlsrv_close($db);
		return $rv;
	}
	
	// 保存数据
	// 添加数据
	protected function insert(array $data)
	{
		$sql = CSql::getInsertSql($this->getTableName(), $data, $this->getIdName());
		if ($sql == "") return 0;
		$db = $this->getDbEngine()->getDb();
		if ($db===false) return 0;
		$stmt = sqlsrv_query($db, $sql, CSql::getParams($data));
		$rv = 0;
		if($stmt)
		{
			$record = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_NUMERIC);
			if($record) $rv = $record[0];
			sqlsrv_free_stmt($stmt);
		}
		sqlsrv_close($db);
		return $rv;
	}
	
	// 更新数据
	protected function update(array $data, array $cond)
	{
		$sql = CSql::getUpdateSql($this->getTableName(), $data, $cond);
		if ($sql == "") return 0;
		$db = $this->getDbEngine()->getDb();
		if ($db===false) return 0;
		//
		$params = CSql::getParams($data);
		foreach($cond as $value)
		{
			array_push($params, $value);
		}
		//
		$stmt = sqlsrv_query($db, $sql, $params);
		$rv = 0;
		if($stmt)
		{	
			$rv = 1;
			sqlsrv_free_stmt($stmt);
		}
		sqlsrv_close($db);
		return $rv;
	}
	
	//
}


?>