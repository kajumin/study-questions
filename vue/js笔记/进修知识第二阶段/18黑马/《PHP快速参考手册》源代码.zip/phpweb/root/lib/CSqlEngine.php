<?php

require_once $_SERVER["DOCUMENT_ROOT"]."/lib/db.php";
require_once $_SERVER["DOCUMENT_ROOT"]."/lib/CSql.php";

class CSqlEngine implements IDbEngine
{
	private $server;
	private $uid;
	private $pwd;
	private $database;
	// 构造函数
	public function __construct($server,$uid,$pwd,$database)
	{
		$this->server = $server;
		$this->uid = $uid;
		$this->pwd = $pwd;
		$this->database = $database;
	}
	//
	public function getEngineType()
	{
		return DbEngineType::SQLSERVER;
	}
	//
	public function getDb()
	{
		$cnninf = array("Database"=> $this->database,
			"UID" => $this->uid,
			"PWD" => $this->pwd,
			"CharacterSet"=>"utf-8");
		return sqlsrv_connect($this->server, $cnninf);
	}
	//
	public function connect()
	{
		try
		{
			$db = $this->getDb();
			if ($db === false){
				return false;
			}else{
				sqlsrv_close($db);
				return true;
			}
		}
		catch(Exception $ex)
		{
			return false;
		}
	}
	// 返回一个查询，没有返回false
	public function getValue($table, $returnfields, array $cond)
	{
		$db = $this->getDb();
		if ($db===false) return false;
		$sql = CSql::getSelectSql($table, $returnfields, 1, $cond);
		$stmt = sqlsrv_query($db, $sql, CSql::getParams($cond));
		$rv = false;
		if($stmt)
		{
			$record = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_NUMERIC);
			if($record) $rv = $record[0];
			sqlsrv_free_stmt($stmt);
		}
		sqlsrv_close($db);
		return $rv;
	}
	
	// 返回array或false，只按返回字段名返回数据
    public function getRecord($table, $returnfields, array $cond)
	{
		$db = $this->getDb();
		if ($db===false) return false;
		$sql = CSql::getSelectSql($table, $returnfields, 1, $cond);
		$stmt = sqlsrv_query($db, $sql, CSql::getParams($cond));
		$rv = false;
		if($stmt)
		{
			$record = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
			if($record) $rv = $record;
			sqlsrv_free_stmt($stmt);
		}	
		sqlsrv_close($db);
		return $rv;
	}
	// 返回二维数组或或false
    public function getRecordset($table, $returnfields, $returncount, array $cond)
	{
		$db = $this->getDb();
		if ($db===false) return false;
		$sql = CSql::getSelectSql($table, $returnfields, $returncount, $cond);
		$stmt = sqlsrv_query($db, $sql, CSql::getParams($cond));
		$rv = false;
		if($stmt)
		{
			$record = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
			if ($record)
			{
				$rv = array();
				while($record = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC))
				{
					array_push($rv, $record);
				}
			}
			sqlsrv_free_stmt($stmt);
		}
		sqlsrv_close($db);
		return $rv;
	}
}

?>