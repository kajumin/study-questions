<?php
require_once $_SERVER["DOCUMENT_ROOT"]."/phpapp/app.php";
$dbe = new CMySqlEngine("localhost","root","DEV_test123456","cdb_demo",3306,"");
$rec = new CMySqlRecord($dbe, "user_main", "userid");
//更新记录
$data = array("phone"=>"778899");
$cond = array("email"=>"tom@xyz.com");
var_dump($rec->save($data, $cond));
?>