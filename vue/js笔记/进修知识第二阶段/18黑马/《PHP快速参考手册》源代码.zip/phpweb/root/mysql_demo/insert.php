<?php
require_once $_SERVER["DOCUMENT_ROOT"]."/phpapp/app.php";
$dbe = new CMySqlEngine("localhost","root","DEV_test123456","cdb_demo",3306,"");
$rec = new CMySqlRecord($dbe, "user_main", "userid");
// 插入新记录
$data = array(
	"email"=>"tom@xyz.com",
	"password"=>sha1("123456"),
	"sex"=>1,
	"acceptemail"=>1,
	"phone"=>"112233",
	"islocked"=>0
);
//
var_dump($rec->save($data, array()));
?>