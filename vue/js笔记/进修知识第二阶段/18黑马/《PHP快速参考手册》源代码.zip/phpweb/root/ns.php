<?php

namespace myns
{
	class ClsA
	{
		public function work()
		{
			echo __METHOD__;
		}
	}
}

?>