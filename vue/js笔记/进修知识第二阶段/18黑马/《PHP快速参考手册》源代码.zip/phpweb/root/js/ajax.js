// 创建XMLHttpRequest对象
function ajaxCreateObject()
{
	var obj = new XMLHttpRequest();
	if(obj == null)
		obj = new ActiveXObject("Microsoft.XMLHTTP");
	return obj;
}

// GET方法发送请求，并返回文本信息
function ajaxGetText(url, param, fn)
{
	var xhr = new XMLHttpRequest();
	if (xhr == null) return;
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
            if (xhr.status == 200 || xhr.status == 304) {
                fn(xhr.responseText);
            }
        }
    };
    if (url.charAt(url.length - 1) != "?") { url += "?"; }
    xhr.open("GET", url + param, true);
    xhr.send(null);
}

// GET方法发送请求，并返回XML数据
function ajaxGetXml(url, param, fn)
{
	var xhr = new XMLHttpRequest();
    if (xhr == null) return;
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
            if (xhr.status == 200 || xhr.status == 304) {
                fn(xhr.responseXML);
            }
        }
    };
    if (url.charAt(url.length - 1) != "?") { url += "?"; }
    xhr.open("GET", url + param, true);
    xhr.send(null);
}

// POST方法发送请求，并返回文本信息
function ajaxPostText(url, param, fn)
{
	var xhr = new XMLHttpRequest();
    if (xhr == null) return;
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
            if (xhr.status == 200 || xhr.status == 304) {
                fn(xhr.responseText);
            }
        }
    };
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;");
    xhr.send(param);
}

// POST方法发送请求，并返回XML数据
function ajaxPostXml(url, param, fn)
{
	var xhr = new XMLHttpRequest();
    if (xhr == null) return;
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
            if (xhr.status == 200 || xhr.status == 304) {
                fn(xhr.responseXML);
            }
        }
    };
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;");
    xhr.send(param);
}
