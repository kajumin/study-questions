<?php
echo 'AJAX测试文本';
?>