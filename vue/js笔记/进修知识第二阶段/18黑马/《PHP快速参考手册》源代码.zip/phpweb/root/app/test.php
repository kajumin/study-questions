<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/phplib/string.php';

var_dump(isEmail('caAaa.com'));
?>