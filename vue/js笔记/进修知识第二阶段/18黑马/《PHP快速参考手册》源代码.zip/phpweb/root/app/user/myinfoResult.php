<?php
require_once $_SERVER["DOCUMENT_ROOT"]."/app/init.php";
// 检查登录状态
session_start();
if (!isset($_SESSION["email"]) || strval($_SESSION["email"])=="")
{
	$_SESSION["return_url"]="/app/user/myinfo.php";
	header("Location: login.php");
}
// 验证码
if (!isset($_REQUEST["checkcode"]) ||
	!CCheckCode::check("myinfo_checkcode", $_REQUEST["checkcode"]))
{
	invalid("验证码输入错误");
}

// 保存个人信息
$user = new CUser();
$cond = array("email"=>$_SESSION["email"]);
$data = array("sex"=>intval($_REQUEST["sex"]));
if (isset($_REQUEST["acceptemail"]))
	$data["acceptemail"]=1;
else
	$data["acceptemail"]=0;
$data["phone"]=$_REQUEST["phone"];
//
if($user->save($data, $cond)>0)
{
	echo "个人信息修改成功，<a href='/'>返回首页</a>";
}else{
	invalid("修改个人信息时产生未知错误，请稍后重试");
}

//
function invalid($msg)
{
	echo "<script type='text/javascript'>";
	echo "alert('$msg');";
	echo "window.open('myinfo.php','_self');";
	echo "</script>";
	exit;
}
?>

