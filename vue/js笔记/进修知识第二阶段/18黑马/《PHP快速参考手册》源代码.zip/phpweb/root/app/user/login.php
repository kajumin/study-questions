<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>用户登录</title>
</head>
<body>
<form action='loginResult.php?<?php echo $_SERVER["QUERY_STRING"]; ?>' method="post">
<h1>用户登录</h1>
<p><label for="email">您的E-mail</label>
<input type="email" id="email" name="email" 
	maxlength="50" required placeholder="xxx@xxx.xxx">

<p><label for="password">登录密码</label>
<input type="password" id="password" name="password" 
	maxlength="15" required>

<p><input type="submit" value="登录">
</form>
</body>
</html>

