<?php
require_once $_SERVER["DOCUMENT_ROOT"]."/phpapp/app.php";
// 分解用户提交数据
extract($_REQUEST);
if(!isset($email))
{
	header("Location: register.php");
	exit;
}

// 检查E-mail地址
$pattern = '/^[a-zA-Z0-9]+-*[a-zA-Z0-9]*@[a-zA-Z0-9]+-*.[a-zA-Z]+.?[a-zA-Z]+$/';
if (preg_match($pattern, $email)!=1)
	invalid('E-mail地址格式错误');
// 检查密码
if (strlen($password)<6 || strcmp($password,$confirm)!=0)
	invalid('密码至少6个字符，并且两次输入要一致');
// 检查性别
$sex = intval($sex);
if ($sex<0 || $sex>2)
	//exit('性别值应该是0到2');
	invalid('性别值应该是0到2');
// 是否接收邮件
if (isset($acceptemail))
	$acceptemail = 1;
else
	$acceptemail = 0;
//

// 检查E-mail地址是否已使用
$user = new CUser();
$cond = array("email"=>$email);
if($user->load("userid", $cond) != false)
	invalid('E-mail地址已使用');
//
// 保存到项目数据库
$data = array("email"=>$email,
"password"=>sha1($password),
"sex"=>$sex,
"acceptemail"=>$acceptemail,
"islocked"=>0);

//
$newid = $user->save($data, array());
//
if ($newid > 0)
	header("Location: login.php");
else
	invalid("对不起！系统繁忙，请稍后再试！");
//

// 验证失败，返回注册页
function invalid($msg)
{
	// 显示提示信息，并返回register.php
	echo "<script type='text/javascript'>";
	echo "alert('",$msg,"');";
	echo "window.history.back();";
	echo "</script>";
	exit;
}
?>