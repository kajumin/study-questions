<?php
require_once $_SERVER["DOCUMENT_ROOT"]."/app/init.php";
CCheckCode::create("myinfo_checkcode");
?>