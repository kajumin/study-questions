<?php

require_once $_SERVER["DOCUMENT_ROOT"]."/app/init.php";

class CUser extends CDbRecord
{
	public function __construct()
	{
		parent::__construct(getDbEngine(), "user_main", "userid");
	}
	
	// 判断登录情况
	public static function logined()
	{
		@session_start();
		return (isset($_SESSION["email"]) && strval($_SESSION["email"])!="");
	}
}
?>