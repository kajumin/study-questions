<?php

// 自动加载类同名文件
function __autoload($classname)
{
	$path = $_SERVER["DOCUMENT_ROOT"]."/app/$classname.php";
	if (!file_exists($path))
		$path = $_SERVER["DOCUMENT_ROOT"]."/lib/$classname.php";
	//
	require_once $path;
}

// 返回项目主数据库引擎对象
function getDbEngineBak()
{
	$dbpath = $_SERVER["DOCUMENT_ROOT"]."/sqlite_db/cdb_demo.db";
	return new CSqliteEngine($dbpath);
}

function getDbEngine()
{
	return new CMySqlEngine("localhost","root","DEV_test123456","cdb_demo");
}


?>