<?php
require_once $_SERVER["DOCUMENT_ROOT"]."/app/init.php";
//
extract($_REQUEST);
//
if(!isset($email) || !isset($password))
	invalid("请输入正确的登录信息");

$user = new CUser();
$cond = array("email"=>$email,"password"=>sha1($password),"islocked"=>0);

if($user->load("userid", $cond) != false)
{
    // 登录成功
    session_start();
    $_SESSION['email']=$email;
	//
	if (isset($re) && $re!="")
		header("Location: $re");
	else
		header("Location: /");
}else{
	invalid("登录失败，请检查您的登录信息");
}


// 登录失败，返回登录页
function invalid($msg)
{
	// 显示提示信息，并返回login.php
	echo "<script type='text/javascript'>";
	echo "alert('",$msg,"');";
	echo "window.open('login.php','_self');";
	echo "</script>";
	exit;
}
?>