<?php

require_once $_SERVER["DOCUMENT_ROOT"]."/app/init.php";

class CChat extends CDbRecord
{
	public function __construct()
	{
		parent::__construct(getDbEngine(), "chat", "rid");
	}
}

?>