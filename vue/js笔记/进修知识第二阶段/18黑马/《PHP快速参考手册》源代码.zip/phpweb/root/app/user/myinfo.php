<?php

require_once $_SERVER["DOCUMENT_ROOT"]."/app/init.php";
// 检查登录状态
session_start();
if (!isset($_SESSION["email"]) || strval($_SESSION["email"])=="")
{
	$_SESSION["return_url"]="/app/user/myinfo.php";
	header("Location: login.php");
}
// 载入用户数据
$user = new CUser();
$rec = $user->load("sex,acceptemail,phone", 
	array("email"=>$_SESSION["email"]));
if($rec===false) exit("载入个人信息错误，请稍后重试");
//
//print_r($rec);
//exit;
// 显示数据表单
echo "<h1>修改个人信息</h1>";
echo "<form id='myinfo' method='post' action='myinfoResult.php'>";
// 性别数据
echo "<p><label for='sex'>您的称呼</label>";
$arr = array("0"=>"保密","1"=>"先生","2"=>"女士");
CForm::radiobuttonlist("sex",$arr,$rec["sex"]);
// 接受我们的邮件
echo "<p>";
CForm::checkbox("acceptemail",
	"<label for='acceptemail'>接收我们的邮件</label>",
	(bool)$rec["acceptemail"]);
// 电话
echo "<p><label for='phone'>电话</label>";
CForm::textbox("phone",htmlspecialchars($rec["phone"]),50);
// 验证码
echo "<p><label for='checkcode'>验证码</label>";
CForm::textbox("checkcode","",5,100);
echo "<img id='img_cc' src='myinfo_checkcode.php' border='0'>";
echo "<a href='javascript:changeImage();'>换一张</a>";
// 提交按钮
echo "<p>";
CForm::input("submit","submit","修改信息");
//
echo "</form>";
?>

<script type="text/javascript">
function changeImage()
{
	var e=document.getElementById("img_cc");
	e.setAttribute("src","myinfo_checkcode.php?ts="+new Date().getTime());
}
</script>