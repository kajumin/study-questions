<?php
    // PHP代码
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<title>PHP页面模板</title>
</head>
<body>
<h1>页面内容</h1>
</body>
</html>