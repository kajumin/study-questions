<?php

$width = 400;
$height = 300;
$img = imagecreatetruecolor($width, $height);
//
$black = imagecolorallocate($img, 0, 0, 0);
$white = imagecolorallocate($img, 255, 255, 255);
$red = imagecolorallocate($img, 255, 0, 0);
$green = imagecolorallocate($img, 0, 255, 0);
$blue = imagecolorallocate($img, 0, 0, 255);
// 修改背景色
imagefilledrectangle($img, 0, 0, $width, $height, $white);
// 以下为图形绘制测试代码

$alpha = imagecolorallocatealpha($img,0,0,255,100);
imagettftext($img, 30,0,50,50,$alpha,
    $_SERVER["DOCUMENT_ROOT"]."/fonts/simsun.ttc","caohuayu.com");


//exit;
// 显示图片
header("Content-type: image/png");
imagepng($img);
imagedestroy($img);
?>