<?php
require_once $_SERVER["DOCUMENT_ROOT"]."/phpapp/app.php";
CCheckCode::create("checkcode");
?>