<?php

require_once $_SERVER["DOCUMENT_ROOT"]."/phpapp/app.php";

if (!isset($_POST["checkcode"]))
	invalid("请从验证码测试页提交数据");


if (CCheckCode::check("checkcode", $_POST["checkcode"]))
	echo "验证码输入正确";
else
	invalid("验证码输入错误");

// 错误处理
function invalid($msg)
{
	echo $msg."<p><a href='checkcodetest.html'>返回验证码测试页</a>";
	exit;
}

?>