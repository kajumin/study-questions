<?php
require_once $_SERVER["DOCUMENT_ROOT"]."/app/init.php";
if (CUser::logined()==false)
{
	header("Location: /app/user/login.php?re=/chat/index.php");
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>网页聊天室</title>
</head>
<body>
<h1>网页聊天室</h1>
<input id="msg" name="msg" type="text" maxlength="50" size="50">
<input type="button" onclick="sendMsg();" value="发送消息">
<span id="sendStatus"></span>

<h3>聊天记录</h3>
<div id="msgList">Loading...</div>
</body>
</html>

<script type="text/javascript" src="/js/ajax.js"></script>

<script type="text/javascript">
// 发送消息
function sendMsg()
{
	var msg = document.getElementById("msg").value;
	var status = document.getElementById("sendStatus");
	if(msg=="")
	{
		status.innerHTML="请输入信息";
		return;
	}
	//
	var url = "send_msg.php";
	var param = "msg="+msg+"&ts="+new Date().getTime();
	ajaxPostText(url,param,function(txt){
		status.innerHTML=txt;
	});
}

// 显示消息
function showMsg()
{
	var msgList = document.getElementById("msgList");
	var url = "msg_list.php";
	var param = "ts="+new Date().getTime();
	ajaxPostText(url,param,function(txt){
		msgList.innerHTML=txt;
	});
	window.setTimeout("showMsg()",2000);
}

// 开始显示信息
showMsg();

</script>