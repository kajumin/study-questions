<?php
require_once $_SERVER["DOCUMENT_ROOT"]."/app/init.php";
//
if (CUser::logined()==false) 
{
	echo "请重新登录！";
	exit;
}
// 载入信息列表，最新30条
// 警告，使用直接调用数据库的方式
$sql = "select email,msg from chat order by rid desc limit 30;";
$db = getDbEngine()->getDb();
$result = $db->query($sql);
if ($result!==false)
{
	while($record = $result->fetch_assoc())
	{
		echo "<p>[";
		echo $record["email"];
		echo "]: ";
		echo htmlspecialchars($record["msg"]);
		echo "</p>";
	}
	$result->free();
}
$db->close();
?>