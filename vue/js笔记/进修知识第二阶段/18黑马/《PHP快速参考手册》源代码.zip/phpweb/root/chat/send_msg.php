<?php
// 接收发送信息
require_once $_SERVER["DOCUMENT_ROOT"]."/app/init.php";
//
if (CUser::logined()==false) 
{
	echo "请重新登录！";
	exit;
}
//
@session_start();
// 将新信息保存到数据库
$data = array();
$data["msg"] = strval($_REQUEST["msg"]);
$data["email"] = strval($_SESSION["email"]);
$data["creationtime"] = strval(CCn::getDateTimeString());
$data["creationip"] = strval($_SERVER["REMOTE_ADDR"]);
$chat = new CChat();
if ($chat->save($data,array())>0)
	echo "发送成功";
else
	echo "信息发送异常，请稍候重试";

?>