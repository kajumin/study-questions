create database cdb_demo;
go

use cdb_demo;
go

create table user_main(
userid bigint identity(1,1) not null,
email nvarchar(50) not null unique,
[password] nvarchar(50) not null,
sex int default(0) check(sex>=0 and sex<=2),
phone varchar(50) default null,
acceptemail int default(0) check(acceptemail>=0 and acceptemail<=1),
islocked int default(1) check(islocked>=0 and islocked<1),
photo varchar(50),
primary key (userid)
);

create table chat(
rid bigint identity(1,1) not null,
email varchar(50) not null,
msg varchar(50) not null,
creationtime datetime,
creationip varchar(23)
);