<?php
// Example 16-5-2.php
$record = dns_get_record("php.net");
print_r($record);
?>
