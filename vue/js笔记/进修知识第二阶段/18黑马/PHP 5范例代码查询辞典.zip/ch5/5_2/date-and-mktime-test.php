<?php
  # Recipe 5-2

  $timestamp = mktime(18, 30, 0, 8, 10, 1997, 1);
  echo date('r (T)', $timestamp);
?>
