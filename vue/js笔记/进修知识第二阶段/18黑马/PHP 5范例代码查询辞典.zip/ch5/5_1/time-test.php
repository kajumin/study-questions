<?php
  # Recipe 5-1  / Example 1
  
  # NOTE: When you run this example, do NOT expect the output 
  # to match that shown in the text!

  echo time();
?>