<?php
	$di = new directoryiterator ("sample7_13");
	echo $di->getPerms();
?>