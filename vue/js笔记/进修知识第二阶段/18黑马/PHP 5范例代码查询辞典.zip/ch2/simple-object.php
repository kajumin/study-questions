<?php
  # "Basic Concepts" example
  
  $ball->color = "green";
  $ball->weight = 100;
  
  printf("The ball's color is %s, and its weight is %d kilos.",
    $ball->color, $ball->weight);
?>