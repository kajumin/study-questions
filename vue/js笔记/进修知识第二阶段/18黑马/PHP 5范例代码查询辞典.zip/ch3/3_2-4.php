<?php
// Example 3-2-4.php
echo "rand(-10, 10) = " . rand(-10, 10) . "\n";
echo "mt_rand(-10, 10) = " . mt_rand(-10, 10) . "\n";
?>
