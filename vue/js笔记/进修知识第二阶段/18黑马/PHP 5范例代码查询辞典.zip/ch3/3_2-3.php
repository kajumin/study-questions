<?php
// Example 3-2-3.php
echo "rand(5, 25) = " . rand(5, 25) . "\n";
echo "mt_rand(5, 25) = " . mt_rand(5, 25) . "\n";
?>
