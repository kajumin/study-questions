<?php
// Example 3-1-7.php
echo intval('123', 10) . "\n";
echo intval('101010', 2) . "\n";
echo intval('123', 8) . "\n";
echo intval('123', 16) . "\n";

echo intval('H123', 32) . "\n";
echo intval('H123', 36) . "\n";
?>
