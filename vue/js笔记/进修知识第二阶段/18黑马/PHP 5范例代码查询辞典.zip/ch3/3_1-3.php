<?php
// Example 3-1-3.php
$a = 5;
$b = $a / 2;
echo "$a / 2 = $b\n";

$a = 6;
$b = $a / 2;
echo "$a / 2 = $b\n";
?>
