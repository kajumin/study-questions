<?php
// Example 3-3-2.php
$val = 100;
$i = log($val);
echo "log($val) = $i\n";
$i10 = log($val) / log(10);
echo "log($val) / log(10) = $i10\n";
$i10 = log10($val);
echo "log10($val) = $i10\n";
?>
