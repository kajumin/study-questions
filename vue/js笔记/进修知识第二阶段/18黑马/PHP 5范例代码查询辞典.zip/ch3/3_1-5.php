<?php
// Example 3-1-5.php
$a = 123;
echo "is_int($a) = " . (is_int($a) ? "true" : "false") . "\n";

$a = '123';
echo "is_int($a) = " . (is_int($a) ? "true" : "false") . "\n";
?>
