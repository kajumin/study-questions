<?php
// Example 3-5-4.php
$i = 123456;
$f = 98765.567;

echo "\$i = " . (string)$i . "\n";
echo "\$f = " . (string)$f . "\n";
?>
