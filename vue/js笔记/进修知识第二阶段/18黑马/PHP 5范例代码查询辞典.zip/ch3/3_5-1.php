<?php
// Example 3-5-1.php
$i = 123;
$f = 12.567;

echo "\$i = $i and \$f = $f\n";
?>
