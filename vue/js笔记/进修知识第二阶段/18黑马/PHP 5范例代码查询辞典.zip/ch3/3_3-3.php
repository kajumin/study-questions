<?php
// Example 3-3-3.php
echo pow(2, 8) . "\n";
echo pow(-2, 5) . "\n";
echo pow(0, 0) . "\n";
echo pow(M_E, 1) . "\n";
echo pow(3.2, 4.5) . "\n";
echo pow(2, -2) . "\n";
echo pow(-2, -3) . "\n";
echo pow(9, 0.5) . "\n";
?> 