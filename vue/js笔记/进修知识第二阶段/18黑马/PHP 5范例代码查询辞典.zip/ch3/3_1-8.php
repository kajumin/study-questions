<?php
// Example 3-1-8.php
chmod("/mydir", 0755);

define('VALUE_1', 0x001);
define('VALUE_2', 0x002);
define('VALUE_3', 0x004);
define('VALUE_4', 0x008);
define('VALUE_5', 0x010);
define('VALUE_6', 0x020);
?>
