<?php
// Example 3-3-1.php
$e = exp(1);
echo "$e\n";
$i = log($e);
echo "$i\n";
?>