<?php
// Example 3-5-3.php
$i = 123456;
$f = 98765.567;

printf("\$i = %x and \$i = %b\n", $i, $i);
printf("\$i = %d and \$f = %f\n", $i, $f);
printf("\$i = %09d and \$f = %0.2f\n", $i, $f);
?>
