<?php
// Example 3-1-11.php
$a=50.3;
$b=50.4;
$c=100.7;

if ($a + $b == $c) {
  echo "$a + $b == $c\n";
}
else {
  echo "$a + $b != $c\n";
}
?>
