<?php
// Example 3-1-1.php
$a="5";
$b= 7 + $a;
echo "7 + $a = $b";
?>
