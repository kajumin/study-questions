<?php
// Example 3-2-2.php
echo "rand() = " . rand() . "\n";
echo "mt_rand() = " . mt_rand() . "\n";
?>
