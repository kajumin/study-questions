<?php
// Example 3-1-2.php
$a = 3.5;
$b = $a & 2;
echo "$a & 2 = $b";
?>
