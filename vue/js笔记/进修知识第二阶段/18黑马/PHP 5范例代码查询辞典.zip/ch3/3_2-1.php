<?php
// Example 3-2-1.php
echo "getrandmax() = " . getrandmax() . "\n";
echo "mt_getrandmax() = " . mt_getrandmax() . "\n";
?>
