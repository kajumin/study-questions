<?php
// Example 10-4-1.php
define('ALIGN_LEFT', 'left');
define('ALIGN_RIGHT', 'right');
define('ALIGN_CENTER', 'center');

$const = 'ALIGN_CENTER';
echo constant($const);
?>