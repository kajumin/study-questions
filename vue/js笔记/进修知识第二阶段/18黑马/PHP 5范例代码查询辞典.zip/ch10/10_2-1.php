<?php
// Example 10-2-1.php
$a = array(
  0=>1,
  1=>2,
  2=>"orange",
  3=>"apple",
  "id"=>7,
  "name"=>"John Smith"
);
print_r($a);
?>
