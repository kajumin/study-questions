<?php
// Example 10-4-2.php
switch($justify) {
  case 1 :  // left
    break;
  case 2 :  // center
    break;
  case 3 :  // right
    break;
}
?>