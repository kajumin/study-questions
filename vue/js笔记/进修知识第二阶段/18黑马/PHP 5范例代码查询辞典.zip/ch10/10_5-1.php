<?php
// Example 10-5-1.php
$a = 7;
function test() {
  $a = 20;
}
test();
echo "\$a = $a\n";
?>
