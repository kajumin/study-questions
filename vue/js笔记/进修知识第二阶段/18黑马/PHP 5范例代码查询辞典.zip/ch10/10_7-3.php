<?php
// Example 10-7-3.php
define('CONST_A', 'test');

${CONST_A} = 27;
echo "\$test = $test\n";
?>
