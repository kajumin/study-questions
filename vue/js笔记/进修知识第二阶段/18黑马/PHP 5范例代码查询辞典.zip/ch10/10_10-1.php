<?php
// Example 10-10-1.php
include 'debug.inc';

$a = array('orange', 'apple');
debug_print($a);
?>
