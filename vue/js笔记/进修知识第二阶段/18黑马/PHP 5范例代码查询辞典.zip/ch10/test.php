<?php
echo "test " . 5 + 7;
echo "\n";
echo "test " . (5 + 7);
echo "\n";
?>