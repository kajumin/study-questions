<?php
// Example 10-4-3.php
define('ALIGN_LEFT', 1);
define('ALIGN_CENTER', 2);
define('ALIGN_RIGHT', 3);

switch($value) {
  case ALIGN_LEFT :
    break;
  case ALIGN_CENTER :
    break;
  case ALIGN_RIGHT :
    break;
}
?>
