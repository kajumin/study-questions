<?php
// Example 10-3-5.php
$a = 10;
$b = 15.7;
echo "The value of \$a is " . $a . " and the value of \$b is " . $b . "\n";
echo 'The value of $a is ' . $a . ' and the value of $b is ' . $b . "\n";
?>
