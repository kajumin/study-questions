<?php
  # Recipe 4-6

  $languages = array('German', 'French', 'Spanish');

  printf("<p>Languages: %s.</p>\n", implode(', ', $languages));
?>