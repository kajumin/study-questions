<?php
// Example 14-1-1.php
header("Content-Type: text/plain");
?>
Hello and welcome to the random number generator!

Your random number is: <?php echo mt_rand(0,100); ?>

This is all for today