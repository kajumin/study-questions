<?php
// Example 14-5-2.php
$slashdot = DOMDocument::load("http://slashdot.org/slashdot.xml");
?>
