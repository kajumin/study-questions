<?php
	$url = "www.apress.com";
	$domain = strstr ($url, ".");
	echo $domain;
?>
