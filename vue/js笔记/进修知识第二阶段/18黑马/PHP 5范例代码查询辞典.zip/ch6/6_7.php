<?php
	$astring = "Hello World";
	echo strrev ($astring);
?>
