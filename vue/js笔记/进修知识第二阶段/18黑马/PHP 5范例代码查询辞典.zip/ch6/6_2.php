<?php
	//Let's find the number of o's in our string.
	$counter = substr_count ("Hello World!","o");
	echo "There are " . $counter . " instance (s) of \"o\" in Hello World!.";
?>