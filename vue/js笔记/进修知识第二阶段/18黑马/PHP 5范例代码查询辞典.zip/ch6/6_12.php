<?php
	$stringone = "something";
	$stringtwo = "something";
	if ($stringone == $stringtwo){
		echo "These two strings are the same!<br />";
	}
	
	//Comparisons.
	if (strncmp ("something","some",4) == 0){
		echo "A correct match!";
	}
?>

