var fs = require("fs");

var p1 = new Promise(function(resolve,reject){
    fs.readFile("./test.txt",function(err,data){
        if(err){
            reject(err);
            return;
        }

        resolve({
            txt : data.toString()
        });
    });
});

var p2 = new Promise(function(resolve,reject){
    fs.readFile("./test2.txt",function(err,data){
        if(err){
            reject(err);
            return;
        }

        resolve({
            txt : data.toString() ,
            next : p1
        });
    });
});
 
p2.then(function(ret){
    console.log(ret.txt)
    return ret.next;
}).then(function(ret){
    console.log(ret.txt)
});