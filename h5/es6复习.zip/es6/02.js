var arr = [4,54,56,52,345,345,1345,346,324,45,34,23423];

var result = arr.find((item)=>{
    return item >= 100 && item % 5 == 0;
});

console.log(result);