var fs = require("fs");

function loadFile(url){
    return new Promise(function(resolve,reject){
         fs.readFile(url,function(err,data){
            if(err){
                reject(err);
                return;
            }
            resolve(data.toString());
        });
    });
}
   
const mm = async () => {
    let txt1 = await loadFile("./test.txt");
    let txt2 = await loadFile("./test.txt");
    console.log(txt1);
    console.log(txt2);
    console.log("done");
}

mm();