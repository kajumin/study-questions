// var arr = [345,234,23,65,45];

// for(let [k,v] of arr.entries()){
//     console.log(k,v);
// }


// console.log([345,234,23,65,45].includes(23))

// [345,234,23,65,45].forEach((item) => {
//     console.log(item);
// });

// var arr = [{"id":0,"name":"小明"},{"id":1,"name":"小花"},{"id":2,"name":"小青"}];

// arr = arr.filter((item) => {
//     return item.id != 1;
// });

// console.log(arr);


// var arr = [345,234,23,65,45].map((item) => {
//     return item * item;
// });
// console.log(arr);


// ["a","b","c","d","e"].reduce((a,b) => {
//     console.log(b);
//     return "哈哈";
// });


// var max;
// [345,234,23,4545,65,565645].reduce((a,b) => {
//     max = a > b ? a : b;
//     return max;
// });
// console.log(max);


// var sum;
// [2,3,4,4,4].reduce((a,b) => {
//     sum = a + b;
//     return sum;
// });
// console.log(sum);


// var result = [45,365,45,6345,3,45,3,445].reduce((a,b)=>{
//     return b >= 60 ? {"jige" : a.jige + 1 , "bujige" : a.bujige} : {"jige" : a.jige , "bujige" : a.bujige  + 1}
// },{"jige" : 0 , "bujige" : 0})
// console.log(result);

 
var arr = [[4,45,4],[0, 1], [2, 3], [4, 5]];
function flatten(arr){
    return arr.reduce((pre , value) => {
        return pre.concat(Array.isArray(value) ? flatten(value) : value);
    },[]); 
}
arr = flatten(arr);
console.log(arr);