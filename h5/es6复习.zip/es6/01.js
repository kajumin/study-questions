function fun(){
    var arr = Array.from(arguments);
    console.log(arr);
    console.log(Array.isArray(arr));
}

fun("白板","幺鸡","二条","三桶","四饼");