import "babel-polyfill";
 
var a = 100;

var p = new Promise(function(resolve,reject){
	if(a == 1){
		resolve();
	}else{
		reject();
	}
});

p.then(function(){
	alert("哈哈");
},function(){
	alert("嘻嘻");
})